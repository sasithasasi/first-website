FUTUREPATH — AI & SOFTWARE CAREER EXPLORER

HOW TO OPEN
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, Firefox, or Safari.
3. No installation or internet connection is required.

FEATURES
- Search and filter eight technology careers
- Five-question career match quiz
- Role detail pop-ups and saved favourites
- Six switchable learning roadmaps
- Skills matrix, salary orientation, and project ideas
- Dark/light theme and print-to-PDF support
- Responsive mobile and desktop layout

FILES
- index.html — page structure
- styles.css — visual design and responsive layout
- script.js — content and interactions

NOTE
Salary figures are broad orientation estimates, not promises. Actual compensation varies by location, company, portfolio, education, skills, and market conditions.
